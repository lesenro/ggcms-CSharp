import { Injectable } from '@angular/core';
import { Validators, AbstractControl, FormGroup, FormControl, FormArray, ValidatorFn, FormBuilder } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
const msgs={
  required:"{name}:必须输入",
  minLength:"{name}:长度应大于{minLength}",
  maxLength:"{name}:长度应小于{maxLength}",
  rangeLength:"{name}:长度应大于{minLength}并小于{maxLength}",
  min:"{name}:不应小于{min}",
  max:"{name}:不应大于{max}",
  email:"{name}:邮箱格式不正确",
  pattern:"{name}:输入格式不正确",
  len:"{name}:长度必须是{len}",
  rName:function(src:string,name:string){
    return src.replace(/{name}/gi,name);
  },
  rMinLength:function(src:string,len){
    return src.replace(/{minLength}/gi,len);
  },
  rMaxLength:function(src:string,len){
    return src.replace(/{maxLength}/gi,len);
  },
  rMin:function(src:string,val){
    return src.replace(/{min}/gi,val);
  },
  rMax:function(src:string,val){
    return src.replace(/{max}/gi,val);
  },
  rLen:function(src:string,val){
    return src.replace(/{len}/gi,val);
  }
};
@Injectable()
export class FormValidatorService {
  frmData:any;
  validateForm: FormGroup;
  constructor() {
    
   }
  initForm(data){
    this.frmData=data;
    var frmArr={};
    data.forEach(item => {
      let itemName=item.name;
      item.formControl=this.GetItemFormGroup(item);
      let ctrl={};
      ctrl[itemName]=item.formControl;
      item.formGroup=new FormGroup(ctrl);
      frmArr[itemName]=item.formControl;
    });
    
    return frmArr;
  }

  GetItemFormGroup(item):FormControl{
    let fctrl= new FormControl(item.value);
    if(item.rules){
      let rules=[];
      item.rules.forEach(r => {
        if(r.name.toLowerCase()=="required"){
          rules.push(Validators.required);
        }else if(r.name.toLowerCase()=="minlength"){
          rules.push(Validators.minLength(r.value));
        }else if(r.name.toLowerCase()=="maxlength"){
          rules.push(Validators.maxLength(r.value));
        }else if(r.name.toLowerCase()=="min"){
          rules.push(Validators.min(r.value));
        }else if(r.name.toLowerCase()=="max"){
          rules.push(Validators.max(r.value));
        }else if(r.name.toLowerCase()=="email"){
          rules.push(Validators.email);
        }else if(r.name.toLowerCase()=="pattern"){
          rules.push(Validators.pattern(r.value));
        }else if(r.name.toLowerCase()=="len"){
          rules.push(this.lenValidator(r.value));
        }else if(r.name.toLowerCase()=="rangelength"){
          rules.push(CustomValidators.rangeLength(r.value));
        }
      });
      fctrl.setValidators(rules);
    }
    return fctrl;
  }
  statusCtrl(item: string): string {
    if (!this.validateForm.controls[item]) {return;}
    const control: AbstractControl = this.validateForm.controls[item];
    if(control.errors){
      control.errors.status="error";
    }
    return control.dirty && control.hasError('status') ? control.errors.status : '';
  }
  
  messageCtrl(item: string): string {
    if (!this.validateForm.controls[item]) return;
    const control: AbstractControl = this.validateForm.controls[item];
    if(control.errors){
      let msg="";
      let frmItem=this.frmData.find(x=>x.name===item);
      if(!frmItem)return;
      let name =frmItem.label||frmItem.name;
      for(let rn in control.errors){
        if(rn.toLowerCase()=="required"){
          msg = msgs.required;
          let rule=frmItem.rules.find(x=>x.name==="required");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
        }else if(rn.toLowerCase()=="rangelength"){
          msg = msgs.rangeLength;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="rangelength");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
          msg = msgs.rMinLength(msg,rule.value[0]);
          msg = msgs.rMaxLength(msg,rule.value[1]);
        }else if(rn.toLowerCase()=="minlength"){
          msg = msgs.minLength;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="minlength");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
          msg = msgs.rMinLength(msg,rule.value);
        }else if(rn.toLowerCase()=="maxlength"){
          msg = msgs.maxLength;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="maxlength");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
          msg = msgs.rMaxLength(msg,rule.value);
        }else if(rn.toLowerCase()=="min"){
          msg = msgs.min;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="min");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
          msg = msgs.rMin(msg,rule.value);
        }else if(rn.toLowerCase()=="max"){
          msg = msgs.max;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="max");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
          msg = msgs.rMax(msg,rule.value);
        }else if(rn.toLowerCase()=="email"){
          msg = msgs.email;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="email");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
        }else if(rn.toLowerCase()=="pattern"){
          msg = msgs.pattern;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="pattern");
          if(rule&&rule.message){
            msg=rule.message;
          }
          msg = msgs.rName(msg,name);
        }else if(rn.toLowerCase()=="len"){
          msg = msgs.len;
          let rule=frmItem.rules.find(x=>x.name.toLowerCase()==="len");
          if(rule&&rule.message){
            msg=rule.message;
          }
          
          msg = msgs.rName(msg,name);
          msg = msgs.rLen(msg,rule.value);
        }
      }
      control.errors.message=msg;
    }
    return control.dirty && control.hasError('message') ? control.errors.message : ''
  }

  private lenValidator(len): ValidatorFn{
    return (control: AbstractControl): { [key: string]: any } => { 
      var v = control.value;
      return v.length === len ? null : { len:true,status: 'error' };
    };
  }
  private rangeLengthValidator(rng): ValidatorFn{
    let range=rng.split(":");
    return (control: AbstractControl): { [key: string]: any } => { 
      if (control.value.length<parseInt(range[0])|| control.value.length>parseInt(range[1])) { 
        return { 
          rangeLength:true,
          status: 'error'
        };
      }
      return null; 
    };
  }
}
