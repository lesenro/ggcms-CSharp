import { BehaviorSubject } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { URLSearchParams } from '@angular/http';
import { Title } from '@angular/platform-browser';

import 'rxjs/Rx';
import { Routes, Router } from "@angular/router";
import { messageModel } from '../BaseModules';
import { LoadingService } from '../components/loading/loading.service';
import { MessageBoxService } from '../components/message-box/message-box.service';
import { ElNotificationService } from 'element-angular';

@Injectable()
export class AppService {
  routes: Routes;
  //取随机码
  randCode() {
    return "rnd_" + this.timeStamp();
  }
  //取时间缀
  timeStamp() {
    return ((new Date()).getTime());
  };
  pageTitle: string = "";
  setPageTitle(t: string) {
    this.pTitle.setTitle(t);
  };
  loading(msg:string="加载中..."){
    this.loadServ.show(msg);
  }
  loadingClose(){
    this.loadServ.close();
  }
  //消息对话框
  MessageBox(msg: string, title?: string, opts?: any) {
    this.msgBox.show(msg,title,opts);
  }
  //显示通知
  showToaster(content: string, header?: string, type?: string, life?) {
    life = life || 3000;
    this.notify.setOptions({duration:life});
    this.notify[type || "info"](content,header || "通知");
  }
  //路由跳转
  goRouter(rname, params?: any) {
    //console.log(rname);
    if (params) {
      this.router.navigate([rname], { queryParams: params });
    } else {
      this.router.navigateByUrl(rname);
    }
    return true;
  };
  //对象转参数
  objectToParams(data: any): string {
    let params: URLSearchParams = new URLSearchParams();
    for (var key in data) {
      if (data.hasOwnProperty(key)) {
        let val = data[key];
        params.append(key, val);
      }
    }
    return params.toString();
  };
  sidebarClosed: boolean = false;
  LoginUser: any;
  //全局通知-提交消息 
  globalSubject = new BehaviorSubject<messageModel>({ msgData: {}, msgType: "" });
  //监听订阅
  globalObservable: Observable<messageModel>;
  constructor(private pTitle: Title, private router: Router,
    private loadServ:  LoadingService,
    private notify: ElNotificationService,
    private msgBox:MessageBoxService

  ) {
    this.globalObservable = this.globalSubject.asObservable();
  }
}
