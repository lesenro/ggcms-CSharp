import { TestBed, inject } from '@angular/core/testing';

import { DynamicGeneratorService } from './dynamic-generator.service';

describe('DynamicGeneratorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DynamicGeneratorService]
    });
  });

  it('should be created', inject([DynamicGeneratorService], (service: DynamicGeneratorService) => {
    expect(service).toBeTruthy();
  }));
});
