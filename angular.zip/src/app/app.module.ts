import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ElModule} from 'element-angular'
import {AppComponent} from './app.component';
import {HttpModule} from '@angular/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AppRoutingModule} from './app-routing.module';
import {AdminService, AppService, LocalStorageService, FormValidatorService,DynamicGeneratorService} from "./services";
import {FormInputComponent,HeaderComponent,MessageBoxComponent,MessageBoxService,LoadingComponent,LoadingService,SidebarComponent,SideMenusComponent,DataGridViewComponent, FileUploadComponent} from './components';
import {IndexComponent, LoginComponent,HomeComponent,AdvertsComponent,AdvertsEditComponent} from "./pages";
import { CustomFormsModule } from 'ng2-validation';
import { CodemirrorModule } from 'ng2-codemirror';

@NgModule({
  declarations: [
    AppComponent,  IndexComponent, LoginComponent,HomeComponent,AdvertsComponent,AdvertsEditComponent,
    FormInputComponent,HeaderComponent, MessageBoxComponent, LoadingComponent,SidebarComponent,SideMenusComponent, DataGridViewComponent,FileUploadComponent, 
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    ElModule.forRoot(),
    AppRoutingModule,
    CodemirrorModule
  ],
  providers: [
    AdminService, AppService, LocalStorageService, FormValidatorService,MessageBoxService,DynamicGeneratorService,LoadingService
  ],
  entryComponents: [MessageBoxComponent,LoadingComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}