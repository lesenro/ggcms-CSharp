import { Component, OnInit, EventEmitter } from '@angular/core';
import { PageData } from '../../services';

@Component({
  selector: 'data-grid-view',
  templateUrl: './data-grid-view.component.html',
  styleUrls: ['./data-grid-view.component.css'],
  inputs:["columns","data","pages","primaryKey"],
  outputs:["onSelect","onAction","onPageChange"]
})
export class DataGridViewComponent implements OnInit {
  onSelect = new EventEmitter<any>();
  onAction = new EventEmitter<any>();
  onPageChange = new EventEmitter<any>();
  primaryKey:string="Id";
  columns:any[]=[];
  data:any[]=[];
  pages: PageData = new PageData();
  selectrows:any=[];
  selectAll:boolean=false;
  constructor() { }

  ngOnInit() {
    //this.columnsInit();
  }
  selectHandle(scope,ev){
    if(scope=="all"){
      this.data.map(x=>{
        x.selected=ev;
      });
    }else{
      scope.selected=ev;
    }
    this.selectrows=this.data.filter(x=>x.selected).map(x=>x[this.primaryKey]);
    this.onSelect.emit(this.selectrows);
  }
  actionHandle(scope,key){
    this.onAction.emit({
      scope:scope,
      action:key
    });
  }
  pageChange(ev){
    this.onPageChange.emit(ev);
  }
}
