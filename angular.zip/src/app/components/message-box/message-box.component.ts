import { Component, OnInit } from '@angular/core';
const defaultOptions = {
  message: "这是一个对话框",
  title: "提示",
  icon: "fa fa-exclamation-circle",
  btns: "ok|cancel",
  //curbtn: opts.curbtn||{html:"<i class='fa fa-car'></i> 自定义",func:()=>{console.log(222222222222222)}},
  extbtns: [],
  width: 500,
  accept: (ev?) => { },
  reject: (ev?) => { },
};

@Component({
  selector: 'app-message-box',
  templateUrl: './message-box.component.html',
  styleUrls: ['./message-box.component.css']
})

export class MessageBoxComponent implements OnInit {
  dialogShow=false;
  options :any;
  ok(ev){
    this.dialogShow=false;
    this.options.accept(ev);
  }
  cancel(ev){
    this.dialogShow=false;
    this.options.reject(ev);
  }
  btnShow(name):boolean{
    return this.options.btns.indexOf(name)!==-1;
  }
  show(opt){
    this.options=Object.assign({},defaultOptions,opt);
    this.dialogShow=true;
  }
  constructor() { 
    this.options=Object.assign({},defaultOptions);
  }

  ngOnInit() {
  }

}
