import { Injectable, Optional, ComponentRef } from '@angular/core';
import {MessageBoxComponent} from './message-box.component'
import { DynamicGeneratorService } from '../../services/dynamic-generator.service';
@Injectable()
export class MessageBoxService {
  dialog: ComponentRef<any>;
  constructor(
    @Optional() private root: MessageBoxComponent,
    private dynamic: DynamicGeneratorService
  ) {
    this.createComponent()
   }
   show(msg: string, title?: string, opts?: any){
     opts.message=msg;
     opts.title=title;
     this.dialog.instance.show(opts);
   }
   createComponent(): void {
    this.dialog = this.dynamic.generator(MessageBoxComponent);
  }
}
