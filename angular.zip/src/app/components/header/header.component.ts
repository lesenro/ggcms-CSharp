import { Component, OnInit } from '@angular/core';
import { AppService, AdminService } from "../../services";
import { MessageBoxService } from '../message-box/message-box.service';
import { ElMessageService } from 'element-angular'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  siteHome=window["GgcmsServerConfig"].serviceUrl;
  iconClass(name:string){
    return "fa fa-lg fa-fw "+name;
  }

  handle(index: string): void {
     switch(index){
          case "clearCache":
          this.clearCache();
          break;

          case "appRestart":
          this.appRestart();
          break;

          case "logout":
          this.logout();
          break;

          case "sidebarSwitch":
          this.sidebarSwitch();
          break;
     }
  }

  logout() {
    this.msgbox.show("是否退出后台管理?", "提醒",{
      accept: () => {
        this.adminServ.logout().then((data) => {
          if (data.Code == 0) {
            this.appServ.goRouter("/login");
          }
        });
      },
    });
    
  };
  
  clearCache() {
    this.msgbox.show("是否要清理系统缓存?", "清理提醒",{
      accept: () => {
        this.adminServ.ClearCache().then(data => {
          if (data.Code == 0) {
            this.message.success('清理成功');
          }
        });
      },
    });
  }
  appRestart() {
    this.msgbox.show("重启应用需要重新登录，是否继续?", "提醒",{
      accept: () => {
        this.adminServ.AppRestart().then(data => {
          if (data.Code == 0) {
            this.message.success('请重新登录')
            this.appServ.goRouter("/login");
          }
        });
      },
    });
  }
  sidebarSwitch() {
    this.appServ.globalSubject.next({ msgType: "sidebarToggler", msgData: {} })
  };
  constructor(
    public adminServ: AdminService,
    public appServ: AppService,
    private message: ElMessageService,
    private msgbox :MessageBoxService) { }

  ngOnInit() {
  }

}
