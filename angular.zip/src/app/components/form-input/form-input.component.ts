import { Component, OnInit,EventEmitter, ViewChild, AfterViewInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { FormValidatorService, AdminService, AppService } from '../../services';
import { CodemirrorComponent } from 'ng2-codemirror';
import 'codemirror/mode/javascript/javascript';
import 'codemirror/mode/css/css';
import 'codemirror/mode/htmlmixed/htmlmixed';
@Component({
  selector: 'form-input',
  templateUrl: './form-input.component.html',
  styleUrls: ['./form-input.component.css'],
  inputs:["item","value"],
  outputs:['valueChange', 'inputChange','onFileUpload']
})
export class FormInputComponent implements OnInit,AfterViewInit {
  @ViewChild('content') codemirror: CodemirrorComponent;
  valueChange = new EventEmitter<any>();
  inputChange = new EventEmitter<any>();
  onFileUpload = new EventEmitter<any>();
  item:any;
  itemFormGroup: FormGroup ;
  inputObservable:Subscription;
  surface:any={};
  dictData=[];

  codemirrorconfig = {
    lineNumbers: true,
    mode: "htmlmixed",
  };
  private validServ: FormValidatorService;
  constructor(
    private fb: FormBuilder,
    private adminServ: AdminService,
    public appServ: AppService, 
  ) { 
    this.validServ=new FormValidatorService();
  }
  fileSelect(ev) {
    if (ev.Code == 0) {
      this.adminServ.fileUpload(ev.Data).then(data => {
        if (data.Code == 0) {
          this.onFileUpload.emit(data);
          this.setValue(data.link);
          this.onChange(data.link);
        }
      });
    } else {
      this.appServ.showToaster(ev.Msg);
    }
  }
  onChange(ev) {
    this.valueChange.emit(ev);
    this.inputChange.emit({...this.item,value: ev});
  };
  ngAfterViewInit() {
  }
  ngOnInit() {
    this.itemFormGroup = this.item.formGroup; 
    this.validServ.frmData=[this.item];
    this.validServ.validateForm=this.itemFormGroup;

    this.item.label=this.item.label||this.item.name;
    if(this.item.rules){
      this.item.rules.forEach(r => {
        if(r.name.toLowerCase()=="required"){
          this.surface.required=r.value;
        }else if(r.name.toLowerCase()=="minlength"){
          this.surface.minlength=r.value;
        }else if(r.name.toLowerCase()=="maxlength"){
          this.surface.maxlength=r.value;
        }else if(r.name.toLowerCase()=="min"){
          this.surface.min=r.value;
        }else if(r.name.toLowerCase()=="max"){
          this.surface.max=r.value;
        }else if(r.name.toLowerCase()=="len"){
          this.surface.maxlength=r.value;
        }
      });
    }
    this.surface.type=this.item.type||"text";
    this.surface.onText=this.item.onText||"";
    this.surface.offText=this.item.offText||"";

    if(this.item.type=="single-select-dict"&&this.item.egroup){
      this.getDictData(this.item.egroup);
    }
  }
  getDictData(dictkey:string){
    this.adminServ.GetDictionaryList(1, true, "SysFlag:0,DictType:"+dictkey).then(data => {
      if (data.Code == 0) {
        this.dictData = data.Data.List;
        if (this.dictData.length > 0 && !this.item.value) {
          this.setValue(this.dictData[0].Value);
        }
      }
    });
  }
  setValue(val){
    var dset={};
    dset[this.item.name]=val;
    this.itemFormGroup.patchValue(dset);
  }
}
