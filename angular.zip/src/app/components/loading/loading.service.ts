import { Injectable, Optional, ComponentRef } from '@angular/core';
import {LoadingComponent} from './loading.component'
import { DynamicGeneratorService } from '../../services/dynamic-generator.service';
@Injectable()
export class LoadingService {
  comRef: ComponentRef<any>;
  constructor(
    @Optional() private root: LoadingComponent,
    private dynamic: DynamicGeneratorService
  ) {
   }
  show(msg: string, opts: any={}){
    this.createComponent();
    opts.message=msg;
    this.comRef.instance.show(opts);
  }
  close(){
    this.comRef.instance.close();
    this.dynamic.destroy(this.comRef);
  }
  createComponent(): void {
    this.comRef = this.dynamic.generator(LoadingComponent);
  }
}
