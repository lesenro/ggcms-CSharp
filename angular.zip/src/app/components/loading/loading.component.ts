import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
const defaultOptions = {
  message: "加载中...",
  fullScreen:false
};
@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.css']
})
export class LoadingComponent implements OnInit {
  showLoading=false;
  options :any={
    message:"",
    fullScreen:true,
  };
  constructor(private cdr: ChangeDetectorRef) { 
    cdr.detach();
    this.options=Object.assign({},defaultOptions);
  }
  show(opt){
    this.showLoading=true;
    this.options=Object.assign({},defaultOptions,opt);
  }
  close(){
    this.showLoading=false;
    this.onClose()
    this.onDestroy()
  }
  ngOnInit() {
    this.cdr.reattach();
  }
  onClose: Function = () => {}
  onDestroy: Function = () => {}
}
