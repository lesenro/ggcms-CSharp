import { Component } from '@angular/core';
import { AppService } from './services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  constructor(public appServ: AppService
  ) {
    //全局消息提醒，对话框
    this.appServ.globalObservable.subscribe(data => {
      if (data.msgType == "sidebarToggler") {//侧边菜单
        this.appServ.sidebarClosed = !this.appServ.sidebarClosed;
      }
    });
  }
}
