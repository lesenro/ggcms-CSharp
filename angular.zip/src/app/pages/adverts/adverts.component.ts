import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { PageData, AppService, AdminService } from "../../services";
const configs={
  listApi:"GetAdvertsList",
  deleteApi:"DelAdverts",
  listUrl:'/index/ads',
  editUrl:'/index/adsEdit',
};
const dataColumns=[
  {
    type:"select",
    label:"全选",
    width:120
  },
  {
    key:"Title",
    label:"标题",
  },
  {
    key:"Url",
    label:"Url"
  },{
    key:"Status",
    label:"状态"
  },{
    type:"action",
    label:"操作",
    width:160,
    actions:[
      {
        name:"编辑",
        key:"edit",
        icon:"edit",
        type:"primary"
      }
    ]
  }
];
@Component({
  selector: 'app-adverts',
  templateUrl: './adverts.component.html',
  styleUrls: ['./adverts.component.css']
})
export class AdvertsComponent implements OnInit {
  dataColumns=dataColumns;
  configs=configs;
  pdata: PageData = new PageData();
  dataList: any[] = [];
  selectIds:any[]=[];
  onAction(ev){
    if(ev.action=="edit"){
      this.appServ.goRouter(configs.editUrl, { id: ev.scope.Id });
    }
  }
  constructor(private route: ActivatedRoute, public appServ: AppService, private adminServ: AdminService) { }

  itemDelete() {

    if (this.selectIds.length == 0) {
      this.appServ.showToaster("请先选择要删除的记录");
      return;
    }
    this.appServ.MessageBox("是否删除：" + this.selectIds.length + " 条记录", "删除提醒",
      {
        accept: () => {
          this.adminServ[configs.deleteApi](this.selectIds).then(data => {
            if (data.Code == 0) {
              this.appServ.showToaster("删除成功");
              this.dataLoad();
            }
          });
        },
      });
  }

  selectRow(ev) {
    this.selectIds=ev;
  }
  pageChange(ev) {
    this.appServ.goRouter(configs.listUrl, { page: ev });
  }
  dataLoad() {
    this.adminServ[configs.listApi](this.pdata.pagenum).then(data => {
      if (data.Code == 0) {
        this.dataList = data.Data.List;
        this.pdata.count = data.Data.Count;
        this.pdata.totalPage = Math.ceil(this.pdata.count / this.pdata.limit);
      }
    });
  }
  
  ngOnInit() {
    this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.pdata.pagenum = +params['page'] || 1;
        this.dataLoad();
      });
  }
}
