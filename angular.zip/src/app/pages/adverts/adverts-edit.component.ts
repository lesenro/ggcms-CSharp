import {Component, OnInit, Inject, forwardRef} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {AppService, AdminService, FormValidatorService} from "../../services";
import {Location} from '@angular/common';
import {FormGroup, FormBuilder} from '@angular/forms';
const configs = {
  listApi: "GetAdvertsList",
  deleteApi: "DelAdverts",
  listUrl: '/index/ads',
  editUrl: '/index/adsEdit'
};
const dataModel = [
  {
    name: "Title",
    value: "",
    label: "标题",
    rules: [
      {
        name: "required",
        value: true,
        message: "标题是必填的"
      }, {
        name: "minLength",
        value: "2"
      }, {
        name: "maxLength",
        value: "200"
      }
    ]
  }, {
    name: "GroupKey",
    value: "",
    label: "广告分组",
    type: "single-select-dict",
    egroup: "province",
    rules: [
      {
        name: "required",
        value: true
      }
    ]
  }, {
    name: "OrderID",
    value: "1",
    label: "排序",
    type: "number",
    rules: [
      {
        name: "min",
        value: 1
      }
    ]
  }, {
    name: "Content",
    value: "",
    label: "内容",
    type: "codemirror"

  }, {
    name: "Status",
    value: "true",
    label: "状态",
    type: 'switch',
    onText: "显示",
    offText: "隐藏"
  }, {
    name: "Url",
    value: "",
    label: "URL地址"
  }, {
    name: "Image",
    value: "",
    label: "图片",
    type: "img-upload"
  }, {
    name: "Describe",
    value: "",
    label: "描述",
    type: 'textarea'
  }
];
const dataInfo = {
  Id: 0,
  Title: "",
  GroupKey: "",
  Content: "",
  OrderID: "1",
  Status: 1,
  Describe: "",
  Url: "",
  Image: "",
  files:[]
};
@Component({selector: 'app-adverts-edit', templateUrl: './adverts-edit.component.html', styleUrls: ['./adverts-edit.component.css']})
export class AdvertsEditComponent implements OnInit {
  configs = configs;
  dataModel = dataModel;
  public editFormGroup : FormGroup = new FormGroup({});
  dataInfo = dataInfo;
  AdsGroups = [];
  fileSelect(ev) {
    if (ev.Code == 0) {
      this
        .adminServ
        .fileUpload(ev.Data)
        .then(data => {
          if (data.Code == 0) {
            let idx = this
              .dataInfo
              .files
              .indexOf(data.Data.url);
            if (idx != -1) {
              this
                .dataInfo
                .files
                .splice(idx, 1);
            }
            this
              .dataInfo
              .files
              .push({"filePath": data.Data[0].url, "fileType": 0, "propertyName": "Image"});
            this.dataInfo.Image = data.link;
          }
        });
    } else {
      this
        .appServ
        .showToaster(ev.Msg);
    }
  }
  dataSave(ev) {
    let sendData = Object.assign({}, this.dataInfo, this.editFormGroup.value);
    this
      .adminServ
      .AdvertsSave(sendData)
      .then(data => {
        if (data.Code == 0) {
          this
            ._location
            .back();
        }
      });
  }
  constructor(@Inject(forwardRef(() => FormBuilder))private fb : FormBuilder, private route : ActivatedRoute, public appServ : AppService, private adminServ : AdminService, private validServ : FormValidatorService, private _location : Location) {}
  config = {
    lineNumbers: true,
    mode: "htmlmixed"
  };
  ngOnInit() {
    let id = -1;
    this.dataModel=dataModel;
    this.editFormGroup = this
      .fb
      .group(this.validServ.initForm(this.dataModel));
    this
      .route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        id = +params['id'] || 0
        if (id > 0) {
          this
            .adminServ
            .GetAdverts(id)
            .then(data => {
              if (data.Code == 0) {
                this.dataInfo = data.Data;
                this
                  .editFormGroup
                  .patchValue(this.dataInfo);
                this.dataInfo.files = [];
              }
            });
        } else {
          setTimeout(() => {
            this.editFormGroup.patchValue(dataInfo);            
          }, 100);
        }
      });
  }

}
