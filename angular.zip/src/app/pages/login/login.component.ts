import { Component, OnInit, forwardRef, Inject } from '@angular/core';
import { ElNotificationService } from 'element-angular';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
  ValidatorFn,
  ValidationErrors,
  FormArray
} from '@angular/forms';

import { Md5 } from 'ts-md5/dist/md5';
import { AdminService, AppService, LocalStorageService, FormValidatorService } from "../../services";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public editFormGroup: FormGroup = new FormGroup({});
  CaptchaUrl: string;
  submiting=true;
  loginInfo = [
      {
      name:"username",
      value:"",
      label:"帐号",
      rules:[{
        name:"required",
        value:true,
        message:"帐号是必填的",
      },
      {
        name:"minLength",
        value:"5",
      },
      {
        name:"maxLength",
        value:"32",
      }],
    },
    {
      name:"password",
      value:"",
      label:"密码",
      type:"password",
      rules:[{
        name:"required",
        value:true,
      },
      {
        name:"minLength",
        value:"5",
      },
      {
        name:"maxLength",
        value:"32",
      }]
    },
    {
      name:"captcha",
      value:"",
      label:"验证码",
      className:"input-inline input-captcha",
      rules:[{
        name:"required",
        value:true,
      },{
        name:"maxLength",
        value:4,
        message:"验证码必须是4位",
      },{
        name:"minLength",
        value:4,
        message:"验证码必须是4位",
      }]
    }
  ];
  
  constructor(
    @Inject(forwardRef(() => FormBuilder)) private fb: FormBuilder,
    public adminServ: AdminService, 
    private appServ: AppService, 
    private localServ: LocalStorageService,
    private validServ: FormValidatorService,
    private notify: ElNotificationService,
  ) { 
    
  }
  

  onSubmit(ev) {
    this.appServ.loading("正在登录，请稍候...");
    var ldata = Object.assign({}, this.editFormGroup.value);
    ldata.password = Md5.hashStr(ldata.password).toString();
    ldata.password = Md5.hashStr(ldata.password + ldata.captcha).toString();
    
    this.adminServ.login(ldata).then(data => {
      this.appServ.loadingClose();
      if (data.Code == 0) {
        this.localServ.setObject("LoginUser", data.Data);
        this.appServ.LoginUser = data.Data;
        this.appServ.goRouter("/index");
      } else {
        this.getCaptchaUrl();
        this.notify.error(data.Msg, "错误");
      }
      
    }, err => {
      this.appServ.loadingClose();
      this.getCaptchaUrl();
      this.notify.error(err, "错误");
    });
  }
  getCaptchaUrl() {
    this.editFormGroup.patchValue({captcha:""});
    this.CaptchaUrl = this.adminServ.ServerBaseUrl + "getCaptcha?" + this.appServ.randCode();
  }
  ngOnInit() {
    this.editFormGroup = this.fb.group(this.validServ.initForm(this.loginInfo));
    //this.validServ.validateForm=this.editFormGroup;
    
    this.getCaptchaUrl() ;
  }
}


